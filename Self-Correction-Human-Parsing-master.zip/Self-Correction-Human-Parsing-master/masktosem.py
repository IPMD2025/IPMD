

import os
import torch
import argparse
import numpy as np
from PIL import Image
from tqdm import tqdm

from torch.utils.data import DataLoader
import torchvision.transforms as transforms

import networks
from utils.transforms import transform_logits
from datasets.simple_extractor_dataset import SimpleFolderDataset
import os.path as osp
import glob
from mask import read_person_mask
from torchvision import transforms as T
import torchvision.transforms.functional as F




def get_arguments():
    """Parse all the arguments provided from the CLI.
    Returns:
      A list of parsed arguments.
    """
    parser = argparse.ArgumentParser(description="Self Correction for Human Parsing")

    parser.add_argument("--dataset", type=str, default='lip', choices=['lip', 'atr', 'pascal'])
    parser.add_argument("--model-restore", type=str, default='', help="restore pretrained model parameters.")
    parser.add_argument("--gpu", type=str, default='0', help="choose gpu device.")
    parser.add_argument("--input-dir", type=str, default='', help="path of input image folder.")
    parser.add_argument("--output-dir", type=str, default='', help="path of output image folder.")
    parser.add_argument("--logits", action='store_true', default=False, help="whether to save the logits.")

    return parser.parse_args()

def may_mkdirs(dir_name):
    # if not os.cam_path.exists(os.cam_path.dirname(os.cam_path.abspath(fname))):
    #     os.makedirs(os.cam_path.dirname(os.cam_path.abspath(fname)))
    if not os.path.exists(os.path.abspath(dir_name)):
        os.makedirs(os.path.abspath(dir_name))
        
def read_image(img_path):
    """Keep reading image until succeed.
    This can avoid IOError incurred by heavy IO process."""
    got_img = False
    if not osp.exists(img_path):
        raise IOError("{} does not exist".format(img_path))
    while not got_img:
        try:
            img = Image.open(img_path).convert('RGB')
            got_img = True
        except IOError:
            print("IOError incurred when reading '{}'. Will Redo. Don't worry. Just chill".format(img_path))
            pass
    return img


def main():
    args = get_arguments()

    gpus = [int(i) for i in args.gpu.split(',')]
    assert len(gpus) == 1
    if not args.gpu == 'None':
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    

    
    save_path=osp.join(args.input_dir, 'sem')
    mask_path=osp.join(args.input_dir, 'mask')
    may_mkdirs(save_path)
    t=T.ToTensor()
    for name in os.listdir(args.input_dir):
            if name != 'mask' and name != 'sem':
                pdir= osp.join(args.input_dir,name)
                
                # may_mkdirs(save_path+"/"+name)
                
                img_dirs = glob.glob(osp.join(pdir, '*.jpg'))
                # may_mkdirs(save_path +"/"+ name+"/"+osp.basename(pdir))
                outputdir =  osp.join(save_path,name)
                maskdir = osp.join(mask_path,name)
                
                
                for img_path in img_dirs:
                    result_path = os.path.join(outputdir, osp.basename(img_path)[:-4] + '.jpg')
                    mask_path1 = os.path.join(maskdir, osp.basename(img_path)[:-4] + '.png')
                    img = read_image(img_path)
                    img = t(img)
                    mask = torch.tensor(read_person_mask(mask_path1)).unsqueeze(0).repeat(3,1,1)
                    sem=(1-mask)*img
                    sem = F.to_pil_image(sem)
                    sem.save(result_path)
            else:
                continue
    return


if __name__ == '__main__':
    main()
